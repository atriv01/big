# Build India Group Website
**Domain**: www.buildindiagroup.org

A modern, responsive website for Build India Group (BIG) - a Delhi-based civil society organization promoting constitutional consciousness and fundamental duties across India.

## 🌟 Features

- **Complete Website**: Hero, About, Programs, Blog, News, Vision, and Contact sections
- **Content Management System**: Easy-to-use admin panel for content updates
- **Responsive Design**: Optimized for desktop, tablet, and mobile devices
- **Indian Theme**: Patriotic color scheme with green, orange, and white
- **Performance Optimized**: Fast loading with optimized images
- **SEO Ready**: Semantic HTML structure for search engine optimization

## 🚀 Quick Start

### Prerequisites
- Node.js (v14 or higher)
- npm or yarn

### Installation
```bash
# Clone the repository
git clone [repository-url]

# Install dependencies
npm install

# Start development server
npm run dev
```

### Admin Setup
For production, change the admin password in `/components/ContentManager.tsx`:
```typescript
const ADMIN_PASSWORD = 'your_secure_password';
```

## 📱 Admin Panel Access

1. **Access**: Press `Ctrl + Shift + A` to reveal admin button
2. **Login**: Use the password (default: `big2024admin`)
3. **Manage**: Edit content across all sections
4. **Backup**: Export/import content for data safety

## 🎨 Design System

### Color Palette
- **Primary Green**: Various shades of green for headers and accents
- **Orange**: Call-to-action buttons and highlights  
- **White/Light**: Clean backgrounds and text areas
- **Gray**: Subtle text and borders

### Typography
- Clean, readable fonts optimized for Indian content
- Proper hierarchy with H1-H4 headings
- Accessible color contrast ratios

## 📁 Project Structure

```
├── components/
│   ├── ContentManager.tsx     # Admin panel
│   ├── HeroSection.tsx       # Landing section
│   ├── AboutSection.tsx      # Organization info
│   ├── ProgramsSection.tsx   # Initiatives display
│   ├── BlogSection.tsx       # Articles & insights
│   ├── NewsSection.tsx       # Latest updates
│   └── ui/                   # Reusable UI components
├── hooks/
│   └── useContent.ts         # Content management hook
├── styles/
│   └── globals.css           # Global styling
└── App.tsx                   # Main application
```

## 🛠 Content Management

### Sections You Can Edit:
- **Hero Section**: Headlines, subtitles, call-to-action
- **About Section**: Organization description and mission
- **Programs**: Add/edit initiatives with icons and status
- **Blog**: Manage articles with authors and categories
- **News**: Update latest news and announcements
- **Contact**: Edit contact information and hours

### Features:
- ✅ Form-based editing (no coding required)
- ✅ Real-time preview
- ✅ Content export/import for backup
- ✅ Persistent storage
- ✅ Image management via Unsplash

## 🌐 Deployment

### Production Ready ✅
This website is ready for production deployment to:
- Netlify (recommended)
- Vercel
- Firebase Hosting
- AWS S3 + CloudFront
- Any static hosting provider

### Build Commands
```bash
# Production build
npm run build

# Preview build locally
npm run preview
```

See `DEPLOYMENT.md` for detailed deployment instructions.

## 🔧 Customization

### Adding New Content Types
1. Update `hooks/useContent.ts` with new data structure
2. Add editing interface in `ContentManager.tsx`
3. Create new section component
4. Import and use in `App.tsx`

### Styling Changes
- Edit `styles/globals.css` for global styles
- Use Tailwind classes for component-specific styling
- Follow the existing green/orange color scheme

## 📖 About Build India Group

Build India Group (BIG) is a civil society organization founded in 2006 by Biraja Mahapatra. The organization focuses on:

- Promoting civic consciousness through Article 51A (Fundamental Duties)
- Educational programs in multiple Indian languages
- Youth engagement in democratic processes
- Building constitutional awareness across India

## 🤝 Contributing

This project was built for Build India Group's specific needs. For customization or improvements:

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📄 License

This project is built for Build India Group. Please respect the organization's branding and content when using this code.

## 🆘 Support

For technical support or questions about the content management system:
1. Check the `DEPLOYMENT.md` guide
2. Review the admin panel documentation
3. Test the export/import functionality

---

**Built with ❤️ for Build India Group's mission of constitutional consciousness and civic education.**