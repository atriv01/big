import React, { useState } from 'react';
import Header from './components/Header';
import HeroSection from './components/HeroSection';
import AboutSection from './components/AboutSection';
import ProgramsSection from './components/ProgramsSection';
import PledgesSection from './components/PledgesSection';
import HaritbolSection from './components/HaritbolSection';
import ForumsSection from './components/ForumsSection';
import BlogSection from './components/BlogSection';
import NewsSection from './components/NewsSection';
import VisionSection from './components/VisionSection';
import Footer from './components/Footer';
import ContentManager from './components/ContentManager';
import { Button } from './components/ui/button';
import { Settings, Eye } from 'lucide-react';
import { Toaster } from './components/ui/sonner';

export default function App() {
  const [showContentManager, setShowContentManager] = useState(false);
  const [showAdminButton, setShowAdminButton] = useState(false);

  // Key combination to show admin button (Ctrl + Shift + A)
  React.useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.ctrlKey && event.shiftKey && event.key === 'A') {
        setShowAdminButton(true);
        setTimeout(() => setShowAdminButton(false), 10000); // Hide after 10 seconds
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <div className="min-h-screen">
      {/* Admin Button - Only visible when activated */}
      {showAdminButton && (
        <div className="fixed top-20 right-4 z-40">
          <Button
            onClick={() => setShowContentManager(true)}
            className="bg-gray-800 hover:bg-gray-900 text-white shadow-lg animate-pulse"
            size="sm"
          >
            <Settings className="h-4 w-4 mr-2" />
            Admin
          </Button>
        </div>
      )}

      <Header />
      <HeroSection />
      <AboutSection />
      <ProgramsSection />
      <PledgesSection />
      <HaritbolSection />
      <ForumsSection />
      <BlogSection />
      <NewsSection />
      <VisionSection />
      <Footer />
      
      <ContentManager 
        isOpen={showContentManager} 
        onClose={() => setShowContentManager(false)} 
      />
      
      <Toaster />
    </div>
  );
}